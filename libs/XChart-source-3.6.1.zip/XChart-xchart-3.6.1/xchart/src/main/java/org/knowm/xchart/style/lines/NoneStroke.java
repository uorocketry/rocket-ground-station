package org.knowm.xchart.style.lines;

import java.awt.*;

/** @author timmolter */
class NoneStroke extends BasicStroke {}
