package org.knowm.xchart.demo.charts;

public interface RealtimeExampleChart {

  public void updateData();
}
